export class User {
    id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    age: number;
    gender: string;
    emailId: string;
    currentCompany: string;
    course: string;
    discipline: string;
    token: string;
}
